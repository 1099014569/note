// pages/movies/movies.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        
    },

    into:function(e){
        let movieName = e.currentTarget.dataset.name
        
        wx.setStorage({
            key: 'movieName',
            data: movieName,
        })
        wx.navigateTo({
            url: '../filmdetails/filmdetails'
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        console.log("-----------moviePage-onload----------")
        this.reqMovieList()

    },

    weekTag: function (moviewList){

        let week=["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        let reg=/(\d+)(?=[月日])/igm
        let dateArr = []

        for(let i=0;i<moviewList.length;i++){
            let str = moviewList[i][0].day;
            let dateStr = `2019/${str.match(reg)[0]}/${str.match(reg)[1]}`;
            let date = new Date(dateStr)
            dateArr.push(date.getUTCDay())
        }

        for(let i=0;i<dateArr.length;i++){

            let item = dateArr[i]
            dateArr[i]=week[item]
        }
        this.setData({dateArr:dateArr})
    },

    reqMovieList: function() {

        let that = this;

        wx.request({
            url: 'http://localhost:8888/movie',
            data: {

            },
            method: "POST",
            header: {
                'content-type': 'application/json'
            },

            success(res) {

                let movieArr = res.data;
                let movieByDay = [];
                let temp = 0;

                movieByDay[temp] = []
                let sameDay = movieArr[0].day;

                for (let i = 0; i < movieArr.length; i++) {
                    if (movieArr[i].day == sameDay) {
                        movieByDay[temp].push(movieArr[i])
                    } 
                    else{

                        sameDay = movieArr[i].day;
                        temp++;

                        movieByDay[temp]=[]
                        movieByDay[temp].push(movieArr[i])
                    }
                }
                that.setData({ movieList: movieByDay })
                that.weekTag(that.data.movieList)
            }

        })

    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {
        
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {},

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {
        
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {
        
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})