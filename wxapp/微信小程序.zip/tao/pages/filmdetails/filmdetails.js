// pages/Film details/Film details.js

let workername = []
let worker = [{
    item: []
}]
let type = [{
    item: []
}]
Page({

    /**
     * 页面的初始数据
     */

    data: {
        current: 1,
        jump: 0,
        fixed: ''
    },

    onclick: function (event) {

        let index = event.currentTarget.dataset.index
        this.setData({
            current: index,
            jump: index
        })
        console.log(this.data.jump)
        wx.pageScrollTo({
            selector: `#item-${this.data.jump}`

        })
    },
    onmove: function (e) {

        if (e.detail.scrollTop >= 280) {
            this.setData({
                fixed: e.detail.scrollTop
            })

        } else {
            this.setData({
                fixed: ''
            })
        }

    },
    /**
     * 生命周期函数--监听页面加载
     */

    onLoad: function (options) {
        let movieName;
        let that = this;
        wx.getStorage({
            key: 'movieName',
            success: function (res) {
                
                movieName = res.data;
                wx.request({
                    url: 'http://localhost:8888/linkmovie',
                    header: {
                        'content-type': 'application/x-www-form-urlencoded'
                    },
                    data: {
                        movieName: movieName
                    },
                    method: 'post',
                    dataType: 'json',
                    responseType: 'text',
                    success: function (res) {
                        
                        console.log(res.data)
                        type[0].item = res.data,
                            that.setData({
                                type: type
                            })
                    },
                    fail: function (res) {
                        console.log("错误");
                    },
                })
            },
        })



    },


    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        wx.getSystemInfoSync().windowWidth
        console.log(wx.getSystemInfoSync().windowWidth)
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})