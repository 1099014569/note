let SqlBase = require("./SqlBase")

class TicketModel extends SqlBase{

    constructor(){
        super()
    }

    select(sql,callback){
        this.sqlQuery(sql,callback)
    }

}

module.exports=TicketModel