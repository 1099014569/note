let mysql = require("mysql")

class SqlBase{

    constructor(){
        this.connection = mysql.createConnection({
            host:"localhost",
            user:"root",
            password:"root",
            port:"3306",
            database:"tao"
        })
        
        this.connection.connect()
    }

    
    sqlQuery(sql, callback) {

        this.connection.query(sql, function (err, data) {
            if (err) {
                console.log("错误：" + err)
                return
            }
            callback(data)
        })

    }

    sqlEnd(){
        this.connection.end();
    }

}

module.exports = SqlBase;