let SqlBase = require("./SqlBase")

class MovieModel extends SqlBase{

    constructor(){
        super()
    }

    select(sql,callback){
        this.sqlQuery(sql,callback)
    }

}

module.exports=MovieModel