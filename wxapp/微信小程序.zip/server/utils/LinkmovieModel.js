let SqlBase = require("./SqlBase")

class LinkmovieModel extends SqlBase{

    constructor(){
        super()
    }

    select(sql,callback){
        this.sqlQuery(sql,callback)
    }

}

module.exports=LinkmovieModel