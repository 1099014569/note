let SqlBase = require("./SqlBase")

class DiscountModel extends SqlBase{

    constructor(){
        super()
    }

    select(sql,callback){
        this.sqlQuery(sql,callback)
    }

}

module.exports=DiscountModel