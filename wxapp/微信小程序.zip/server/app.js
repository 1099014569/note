let express = require("express");
let bodyParser = require("body-parser");
let app = express();
let urlencodedParser = bodyParser.urlencoded({
    extended: false
});

app.use(bodyParser.urlencoded({ extended: false }))

//解决跨域问题
app.all("*", function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
    res.header("X-Powered-By", " 3.2.1");
    next();
});
//正在热映页面
app.post("/movie",urlencodedParser,function(req,res){

    let MovieModel=require("./utils/MovieModel")
    let movie=new MovieModel()
    let sql= `SELECT * FROM movies`

    movie.select(sql,function(data){
        res.json(data)
    })

})
//优惠券页面
app.post("/discount",urlencodedParser,function(req,res){

    let DiscountModel=require("./utils/DiscountModel")
    let discount=new DiscountModel()
    let sql= `SELECT * FROM discount`

    discount.select(sql,function(data){
        res.json(data)
    })

})
//已购电影票
app.post("/ticket",urlencodedParser,function(req,res){
    let TicketModel=require("./utils/TicketModel");
    let ticket=new TicketModel();
    let sql=`SELECT * FROM ticket`

    ticket.select(sql,function(data){
        res.json(data);
    })
})

//影片详情
app.post("/linkmovie", urlencodedParser,function(req,res){
    let movieName= req.body.movieName;
    console.log(movieName)
    let LinkmovieModel=require("./utils/LinkmovieModel");
    let linkmovie=new LinkmovieModel();
    let sql = `select * from moviedetails inner join movieimg on moviedetails.id=movieimg.movie_id where moviedetails.moviename="${movieName}"`;

    linkmovie.select(sql,function(data){
        res.json(data);
    })
});

app.listen(8888, function () {
    console.log("启动成功")
});