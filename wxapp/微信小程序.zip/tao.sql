/*
Navicat MySQL Data Transfer

Source Server         : master
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : tao

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2019-10-17 20:15:03
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for discount
-- ----------------------------
DROP TABLE IF EXISTS `discount`;
CREATE TABLE `discount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `info` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of discount
-- ----------------------------
INSERT INTO `discount` VALUES ('1', '咪咚影城代金券', '限复仇者联盟4：终局之战使用，暂不抵扣服务费', '2019-05-23', '5');
INSERT INTO `discount` VALUES ('2', '淘票票电影代金券', '全国通用 不限影片|不可和活动叠加使用|票价满35元可用', '2019-02-11', '5');
INSERT INTO `discount` VALUES ('3', '淘票票新春电影红包', '不可和活动叠加使用|票价满45元可用', '2019-02-11', '5');
INSERT INTO `discount` VALUES ('4', '淘票票电影代金券', '不可和活动叠加使用|票价满35元可用', '2018-10-05', '5');
INSERT INTO `discount` VALUES ('5', '微博电影代金券', '微博电影购票可用|票价满30元可用', '2017-02-08', '5');

-- ----------------------------
-- Table structure for moviedetails
-- ----------------------------
DROP TABLE IF EXISTS `moviedetails`;
CREATE TABLE `moviedetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `moviename` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `cometime` varchar(255) NOT NULL,
  `jianjie` varchar(255) NOT NULL,
  `actornum` int(11) DEFAULT NULL,
  `imgnum` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of moviedetails
-- ----------------------------
INSERT INTO `moviedetails` VALUES ('1', '迟来的告白', '剧情/中国大陆/105分钟', '2019-10-17 中国大陆上映', '该影片由全国扶贫宣传教育中心担任专业指导，李彬担纲导演，《中国扶贫》杂志社社长曹金龙担任总策划、执行总编文炜参与编剧，伊珊担任总制片人，董波、罗米、乔立生、王志鹏、韩福利等主演。\\r\\n影片讲述了退役军人余穆只身赴贫困山村以志愿者身份加入驻村工作队，投身脱贫攻坚战，只为一份爱的承诺……', '4', '12');
INSERT INTO `moviedetails` VALUES ('2', '沉睡魔咒2', '奇幻 / 冒险 / 家庭 / 美国 / 119分钟', '2019-10-18 中国大陆上映 ', '《沉睡魔咒》续集将讲述魔女玛琳菲森（朱莉）和将成为女王的爱洛公主（范宁）关系缓和但依旧复杂，但两人要联手对付新的反派，保护森林王国和那里神奇的动物们。', '34', '121');
INSERT INTO `moviedetails` VALUES ('3', '急速逃脱', '悬疑 / 动作 / 德国 / 109分钟', '2019-10-12 中国大陆上映 ', '卡尔是一名建筑商人，某天送儿女上学时突然接到一通陌生电话，说车上安放了炸弹，一离开座椅炸弹就会爆炸，如果报警就摇控炸车。狭小的车内空间顿时将三人的不安和紧张感无限放大…中途剧情紧凑反转不断，而警察调查结果竟将犯罪嫌疑人锁定为卡尔自己，随着时间流逝，卡尔面临即将失去所有财富、性命甚至家庭的多重危机将如何解决？最终结局又会出现怎样的反转？', '12', '33');
INSERT INTO `moviedetails` VALUES ('4', '双子杀手', '剧情 / 动作 / 美国 / 117分钟', '2019-10-18 中国大陆上映 ', '美国国防情报局特工亨利（威尔·史密斯饰），准备退休之际意外遭到一名神秘杀手的追杀，在两人的激烈较量中，他发现这名杀手竟然是年轻了20多岁的自己，一场我与我的对决旋即展开，而背后的真相也逐渐浮出水面。', '25', '176');
INSERT INTO `moviedetails` VALUES ('5', '航海王：狂热行动', '动画 / 冒险 / 日本 / 101分钟', '2019-10-18 08:00 中国大陆上映 ', '《航海王：狂热行动》是“航海王系列”第14部剧场版，也是《航海王》动画二十周年纪念之作。以超新星为代表的众多航海家纷纷现身世界最大的航海家庆典——航海世博会。草帽航海团也收到了主办者费斯塔的邀请函，搭乘万里阳光号前往。原以为航海家们的狂热世博会只是为争夺“航海王罗杰留下的宝藏”，就在神秘宝藏争夺战如火如荼之际，阻挡在路飞等人面前的可怕威胁道格拉斯·巴雷特突然现身！暗藏阴谋的敌我混战一触即发……', '23', '155');

-- ----------------------------
-- Table structure for movieimg
-- ----------------------------
DROP TABLE IF EXISTS `movieimg`;
CREATE TABLE `movieimg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `movie_id` int(11) DEFAULT NULL,
  `actorimg` varchar(255) DEFAULT NULL,
  `juimg` varchar(255) DEFAULT NULL,
  `actorname` varchar(255) DEFAULT NULL,
  `actor` varchar(255) DEFAULT NULL,
  `mainimg` varchar(255) DEFAULT NULL,
  `wantsee` varchar(255) DEFAULT NULL,
  `dynamicsimg` varchar(255) DEFAULT NULL,
  `dynamicsfont` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of movieimg
-- ----------------------------
INSERT INTO `movieimg` VALUES ('1', '1', 'https://gw.alicdn.com/i1/TB12SRvixD1gK0jSZFsXXbldVXa_.jpg_400x400Q50.jpg_.webp', '//gw.alicdn.com/i3/TB1KO79iYr1gK0jSZR0XXbP8XXa_.jpg_600x600Q30.jpg_.webp', '李彬', '导演', '//gw.alicdn.com/i4/TB1JcdxiAY2gK0jSZFgXXc5OFXa_.jpg_250x250Q30.jpg_.webp', '322', '//gw.alicdn.com/i3/TB1tTNrjkL0gK0jSZFxXXXWHVXa_.jpg_360x360Q30.jpg_.webp', '电影《迟来的告白》山西首映   动人扶贫事迹点燃三晋大地');
INSERT INTO `movieimg` VALUES ('2', '1', 'https://gw.alicdn.com/i4/TB1arlAiEY1gK0jSZFCXXcwqXXa_.jpg_400x400Q50.jpg_.webp', '//gw.alicdn.com/i3/TB1Tog8i.T1gK0jSZFhXXaAtVXa_.jpg_600x600Q30.jpg_.webp', '董波', '演员', null, null, 'https://img-dt.alicdn.com/199078/1570676412602.jpg?x-oss-process=image/resize,w_790', '致敬扶贫英雄！献礼片《迟来的告白》发布长版预告');
INSERT INTO `movieimg` VALUES ('3', '1', '//gw.alicdn.com/i1/TB11wBUmlDH8KJjSszcXXbDTFXa_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i3/TB17HZ_i1H2gK0jSZFEXXcqMpXa_.jpg_600x600Q30.jpg_.webp', '罗米', '演员', null, null, null, null);
INSERT INTO `movieimg` VALUES ('4', '1', '//gw.alicdn.com/i3/TB1JCzcc0rJ8KJjSspaXXXuKpXa_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i1/TB1ktgriEz1gK0jSZLeXXb9kVXa_.jpg_600x600Q30.jpg_.webp', '乔立生', '演员', null, null, null, null);
INSERT INTO `movieimg` VALUES ('5', '2', '//gw.alicdn.com/i4/TB11ckZLXXXXXcHapXXXXXXXXXX_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i3/TB1qe99i8v0gK0jSZKbXXbK2FXa_.jpg_400x400Q30.jpg_.webp', '乔阿吉姆·罗恩尼', '导演', '//gw.alicdn.com/i2/TB1fvSghND1gK0jSZFyXXciOVXa_.jpg_250x250Q30.jpg_.webp', '35.7万', 'https://img-dt.alicdn.com/185056/1571231495258.png?x-oss-process=image/resize,w_790', '《沉睡魔咒2》倒计时2天，请查收“魔尔王国观光邀请函”');
INSERT INTO `movieimg` VALUES ('6', '2', '//gw.alicdn.com/i2/TB1.7LUKYvpK1RjSZPiXXbmwXXa_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i3/TB1akIXlCfD8KJjSszhXXbIJFXa_.jpg_250x250q30.jpg', '安吉丽娜·朱莉', '演员', null, null, 'https://img-dt.alicdn.com/185056/1571143460815.png?x-oss-process=image/resize,w_790', '《沉睡魔咒2》倒计时3天！解锁教母×小怪物的正确打开方式');
INSERT INTO `movieimg` VALUES ('7', '2', '//gw.alicdn.com/i1/TB1g2iKhUY1gK0jSZFMXXaWcVXa_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i3/TB1akIXlCfD8KJjSszhXXbIJFXa_.jpg_250x250q30.jpg', '艾丽·范宁', '演员', null, null, null, null);
INSERT INTO `movieimg` VALUES ('8', '2', '//gw.alicdn.com/i2/TB13XgKrmzqK1RjSZFpXXakSXXa_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i1/TB12Qjii7T2gK0jSZFkXXcIQFXa_.jpg_600x600Q30.jpg_.webp', '切瓦特·埃加福特', '演员', null, null, null, null);
INSERT INTO `movieimg` VALUES ('9', '3', '//gw.alicdn.com/i2/TB1SPv7ghn1gK0jSZKPXXXvUXXa_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i2/TB1fVHajbr1gK0jSZR0XXbP8XXa_.jpg_600x600Q30.jpg_.webp', '克里斯蒂安·阿瓦特', '导演', '//gw.alicdn.com/i3/TB14Cw.hlv0gK0jSZKbXXbK2FXa_.jpg_250x250Q30.jpg_.webp', '2.8万', '//gw.alicdn.com/i3/TB16P5zjX67gK0jSZPfXXahhFXa_.jpg_360x360Q30.jpg_.webp', '悬疑佳作《急速逃脱》正在热映悬疑外衣下包裹戳心现实问题');
INSERT INTO `movieimg` VALUES ('10', '3', '//gw.alicdn.com/i1/TB19C3QcS_I8KJjy0FoXXaFnVXa_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i2/TB1yKDXjoT1gK0jSZFhXXaAtVXa_.jpg_600x600Q30.jpg_.webp', '沃坦·维尔克·默林', '演员', null, null, '//gw.alicdn.com/i1/TB1muLgi4D1gK0jSZFsXXbldVXa_.jpg_360x360Q30.jpg_.webp', '小语种悬疑电影《急速逃脱》热映 口碑获赞持续走高');
INSERT INTO `movieimg` VALUES ('11', '3', '//gw.alicdn.com/tfscom/TB18CV6oCYH8KJjSspdXXcRgVXa.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i4/TB1tTi_jeT2gK0jSZFvXXXnFXXa_.jpg_600x600Q30.jpg_.webp', '汉娜·赫茨施普龙', '演员', null, null, null, null);
INSERT INTO `movieimg` VALUES ('12', '3', '//gw.alicdn.com/i3/TB1BpTUcNPI8KJjSspoXXX6MFXa_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i1/TB1VXeFiV67gK0jSZPfXXahhFXa_.jpg_600x600Q30.jpg_.webp', '克里斯蒂安娜·保罗', '演员', null, null, null, null);
INSERT INTO `movieimg` VALUES ('13', '4', '//gw.alicdn.com/i1/TB1aqd1JpXXXXXqXFXXXXXXXXXX_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i1/TB18mNsjrH1gK0jSZFwXXc7aXXa_.jpg_600x600Q30.jpg_.webp', '李安', '导演', '//gw.alicdn.com/i4/TB1BvxCiq61gK0jSZFlXXXDKFXa_.jpg_250x250Q30.jpg_.webp', null, '//gw.alicdn.com/i3/TB14ulrjAL0gK0jSZFxXXXWHVXa_.jpg_360x360Q30.jpg_.webp', '《双子杀手》曝威尔·史密斯终极预告  被赞“超级3D电影”，震撼视觉前所未有');
INSERT INTO `movieimg` VALUES ('14', '4', '//gw.alicdn.com/i3/TB1VpG3bpuWBuNjSszbXXcS7FXa_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i4/TB17_4qjAL0gK0jSZFxXXXWHVXa_.jpg_600x600Q30.jpg_.webp', '威尔·史密斯', '演员', null, null, '//gw.alicdn.com/i1/TB1AmTfjoH1gK0jSZSyXXXtlpXa_.jpg_360x360Q30.jpg_.webp', '《双子杀手》李安高晓松对话年轻人  李安爆料电影原有三种结局');
INSERT INTO `movieimg` VALUES ('15', '4', '//gw.alicdn.com/i4/TB1Wry3bpuWBuNjSszbXXcS7FXa_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i2/TB1Y_psjxD1gK0jSZFKXXcJrVXa_.jpg_600x600Q30.jpg_.webp', '玛丽·伊丽莎白·文斯蒂德', '演员', null, null, null, null);
INSERT INTO `movieimg` VALUES ('16', '4', '//gw.alicdn.com/i2/TB11i9_bv9TBuNjy1zbXXXpepXa_.jpg_320x320Q30.jpg_.webp', '//gw.alicdn.com/i1/TB1ui0qjAY2gK0jSZFgXXc5OFXa_.jpg_600x600Q30.jpg_.webp', '克里夫·欧文', '演员', null, null, null, null);
INSERT INTO `movieimg` VALUES ('17', null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for movies
-- ----------------------------
DROP TABLE IF EXISTS `movies`;
CREATE TABLE `movies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `people_num` varchar(11) NOT NULL,
  `director` varchar(255) NOT NULL,
  `performer` varchar(255) NOT NULL,
  `day` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of movies
-- ----------------------------
INSERT INTO `movies` VALUES ('1', '始石疯暴', '//gw.alicdn.com/i2/TB1ehbwhET1gK0jSZFhXXaAtVXa_.jpg_160x160Q30s100.jpg_.webp', '843', '赵发华', '侯冰玉 钟扬 百荷 武术', '10月11日');
INSERT INTO `movies` VALUES ('2', '犯罪现场', '//gw.alicdn.com/i1/TB1hnIfibr1gK0jSZFDXXb9yVXa_.jpg_160x160Q30s100.jpg_.webp', '132万', '冯志强', '古天乐 张继聪 宣萱', '10月12日');
INSERT INTO `movies` VALUES ('3', '急速逃脱', '//gw.alicdn.com/i3/TB14Cw.hlv0gK0jSZKbXXbK2FXa_.jpg_160x160Q30s100.jpg_.webp', '2.3万', '克里斯蒂安·阿瓦特', '克里斯蒂安娜·保罗', '10月12日');
INSERT INTO `movies` VALUES ('4', '双子杀手', '//gw.alicdn.com/i4/TB1BvxCiq61gK0jSZFlXXXDKFXa_.jpg_160x160Q30s100.jpg_.webp', '34.2万', '李安', '威尔·史密斯', '10月18日');
INSERT INTO `movies` VALUES ('5', '航海王：狂热行动', '//gw.alicdn.com/i4/TB1CuU2hq67gK0jSZFHXXa9jVXa_.jpg_160x160Q30s100.jpg_.webp', '33.3万', '大塚隆史', '田中真弓 冈村明美', '10月18日');

-- ----------------------------
-- Table structure for ticket
-- ----------------------------
DROP TABLE IF EXISTS `ticket`;
CREATE TABLE `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `adress` varchar(255) NOT NULL,
  `ticketNum` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ticket
-- ----------------------------
INSERT INTO `ticket` VALUES ('1', '流浪地球', '万达影城（新都和顺广场店）', '2', '2019-02-07');
INSERT INTO `ticket` VALUES ('2', '美人鱼 ', '成都万达国际影城新都店', '3', '2016-02-14');
INSERT INTO `ticket` VALUES ('3', '绝世高手', '太平洋影城（天海店）', '2', '2017-07-09');
